# Extension Market

![License](https://img.shields.io/badge/license-MIT-blue.svg) [![Latest Stable Version](https://img.shields.io/packagist/v/bilgehanars/extmar.svg)](https://packagist.org/packages/bilgehanars/extmar)

A [Flarum](http://flarum.org) extension. Basic Extension Market For Flarum

### Installation

Use [Bazaar](https://discuss.flarum.org/d/5151-flagrow-bazaar-the-extension-marketplace) or install manually with composer:

```sh
composer require bilgehanars/extmar
```

### Updating

```sh
composer update bilgehanars/extmar
```

### Links

- [Packagist](https://packagist.org/packages/bilgehanars/extmar)
